console.log ('Vladimir Guerrero Jr.');
console.log ('Bo Bichette');
console.log ('Hyun_Jin_Ryu');
console.log ('George Springer');
console.log ('Teoscar Hernander');

console.log(false);

var message = 'Were they really the top 5 player in 2023?';

console.log(message)
